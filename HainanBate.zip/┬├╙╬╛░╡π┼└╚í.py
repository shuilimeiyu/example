import requests
from urllib import request
from lxml import etree

def get_html():
    headres = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36'
    }
    url = "https://www.explorehainan.com/sitefiles/hnly_zh/xml/meijing/changgui/changgui.json"
    request.urlretrieve(url,'./demo.json')

get_html()
