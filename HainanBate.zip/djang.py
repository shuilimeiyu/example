import pymysql
# import csv
# # 打开数据库连接
# list_id = []
# list_image = []
db = pymysql.connect("localhost", "root", "", "hainan_beta")

# 使用cursor()方法获取操作游标
cursor = db.cursor()

# def input():
#
#
#     # SQL 查询语句
#     sql = 'SELECT * FROM tourism_characteristics'
#     try:
#         # 执行SQL语句
#         cursor.execute(sql)
#         # 获取所有记录列表
#         results = cursor.fetchall()
#         for row in results:
#             id = row[0]
#             image = row[3]
#             list_id.append(id)
#             list_image.append(image)
#
#
#     except:
#         print("Error: unable to fetch data")
#     return list_id,list_image
def update(image,title):
    # SQL 更新语句
    sql = f"UPDATE tourism_characteristics SET image = '{image}' WHERE title ='{title}'"
    print(sql)
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 提交到数据库执行
        db.commit()
    except:
        # 发生错误时回滚
        print(title)
        db.rollback()
# id,image = input()
# for id1,image1 in zip(id,image):
#     image2 = image1.split('1')
#     print(image2)
#     # update(id1)
import json
with open('demo.json', 'r',encoding="utf-8") as f:
    data = json.load(f)
    list1 = list(data)
    for list2 in list1:
        id,bt,ctid,image = list2['id'],list2['bt'],list2['ctid'],'https://www.explorehainan.com/'+list2['image']
        path = '/image/'
        image_path=path+image.split('/')[-1]
        # request.urlretrieve(image,image_path)
        update(image_path,bt)
        # print(image_path,bt)


