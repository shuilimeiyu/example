from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from App.models import User,Article
from django.contrib.auth.hashers import make_password
# Create your views here.
def index(request):
    print(request.user.username)
    return render(request,'index.html',locals())
def left_sidebar(request):
    return render(request,'left-sidebar.html',locals())
def no_sidebar(request):
    return render(request, 'no-sidebar.html', locals())
def right_sidebar(request):
    return render(request, 'right-sidebar.html', locals())
def login__(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        if username and password:
            user = authenticate(username=username, password=password)
            if user is not None:
                # 将用户数据保存在 session 中，即实现了登录动作
                login(request, user)
                return redirect("/index/")
            else:
                message = "账号或者密码出错"
        else:
            message = "请输入账号或者密码"
    return render(request, 'login.html', locals())
def register(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        password2 = request.POST['password2']
        email = request.POST['email']
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']

        if password != password2:
            message = "两次输入的密码不同！"
            print(message)
            return render(request, 'register.html', locals())
        else:
            pd_username = User.objects.filter(username=username)
            if pd_username:
                message = "用户名已经存在！"
                print(message)
                return render(request, 'register.html', locals())
            pd_email = User.objects.filter(email=email)
            if pd_email:
                message = "邮箱已经存在！"
                print(message)
                return render(request, 'register.html', locals())
            mpwd = make_password(password, None, 'pbkdf2_sha256')
            User.objects.create(username=username, password=mpwd, email=email, first_name=first_name,last_name=last_name)
            return redirect('/login/')
    # User.objects.create_user('username','email.@qq.com','password')
    return render(request, 'register.html', locals())